#' ntickets function: project 1
#'
#' @importFrom stats dbinom pnorm
#' @param N numeric vector
#' @param gamma numeric vector
#' @param p numeric vector
#'
#' @return numeric vector
#' @export
#'
#' @examples ntickets(400, 0.02,0.95)
ntickets <- function(N, gamma, p) {
  # Discrete distribution
  cumulative_prob_discrete <- 0
  nd <- 0
  while (cumulative_prob_discrete < gamma) { #if the cumulative probability discrete function is less than gamma, this implies the value falls within 1 - gamma and does not produce an n that overbooks the plane
    cumulative_prob_discrete <- 1 - sum(dbinom(0:N, nd, p))
    nd <- nd + 1
  }
  nd <- nd - 1 # This takes into consideration when while loop crosses the line of its logical expression.

  # Normal approximation
  cumulative_prob_normal <- 0
  nc <- 0
  while (cumulative_prob_normal < gamma) { #if the cumulative probability normal function is less than gamma, this implies the value falls within 1 - gamma and does not produce an n that overbooks the plane
    cumulative_prob_normal <- 1 - pnorm(N, mean = nc * p, sd = sqrt(nc * p * (1 - p)))
    nc <- nc + 0.001 # agrees with continuous nature of the function.
  }
  nc <- nc - 0.001 # This takes into consideration when while loop crosses the line of its logical expression.

  # Plot
  n_values <- seq(N, length.out = 30)
  objective_values_discrete <- sapply(n_values, function(nd) 1 - sum(dbinom(0:N, nd, p)) - gamma) # f(nd) plotted
  objective_values_normal <- sapply(n_values, function(nc) 1 - pnorm(N, mean = nc * p, sd = sqrt(nc * p * (1 - p))) - gamma) #f(nc) plotted

  plotd <- plot(n_values, objective_values_discrete, type = "b", col = "red", #type b implies discrete line.
                xlab = "Number of Tickets Sold (n)", ylab = "Objective Function",
                main = "Objective Function vs. Number of Tickets Sold (Discrete)",
                ylim = c(0, 1))
  abline(v = nd, h = 0) #highlights intersection point
  plotd

  plotc <- plot(n_values, objective_values_normal, type = "l", col = "blue",
                xlab = "Number of Tickets Sold (n)", ylab = "Objective Function",
                main = "Objective Function vs. Number of Tickets Sold (Continuous)",
                ylim = c(0, 1))
  abline(v = nc, h = 0) #highlights intersection point
  plotc

  # Print results
  print(list(nd = nd, nc = nc, N = N, p = p, gamma = gamma))
}
