#' Normal Curve Function
#'
#' @importFrom graphics polygon
#' @param mu numeric vector
#' @param sigma numeric vector
#' @param a numeric vector
#' @param x random variable
#'
#' @return numeric vector
#' @export
#'
#' @examples myncurve(mu = 10, sigma = 5, a = 15)
myncurve = function(mu, sigma, a,x){
  curve(dnorm(x,mean=mu,sd=sigma), xlim = c(mu-3*sigma, mu + 3*sigma))
  xcurve=seq(mu-3*sigma,a,length=1000)
  ycurve <- dnorm(xcurve, mean=mu, sd=sigma)
  polygon(c(mu-3*sigma,xcurve,a),c(0,ycurve,0),col="Red")
  list(mu = mu, sigma = sigma)
}
